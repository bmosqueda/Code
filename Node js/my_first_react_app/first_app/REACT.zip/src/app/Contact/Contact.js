import React from 'react';

const Contact = () => <h1>Soy el Contact</h1>;

export default Contact;