import React from 'react';

const Error404 = () => <h1>404 NOT FOUND</h1>;

export default Error404;