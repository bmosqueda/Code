import React from 'react';

const Home = () => <h1>Soy el Home</h1>;

export default Home;