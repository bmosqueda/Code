import React from 'react';

const About = () => <h1>Soy el About</h1>;

export default About;