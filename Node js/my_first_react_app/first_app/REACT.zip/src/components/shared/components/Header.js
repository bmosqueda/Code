import React from 'react';

const Header = () => <h1>Soy el header</h1>;

export default Header;